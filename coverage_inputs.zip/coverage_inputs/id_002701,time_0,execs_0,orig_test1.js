console.log('AFL++ test input');
