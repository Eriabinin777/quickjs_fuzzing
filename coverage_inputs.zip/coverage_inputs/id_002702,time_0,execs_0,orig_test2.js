let x = 5; if (x > 3) { throw 'Error'; }
